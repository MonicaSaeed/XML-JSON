/*import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

@WebServlet("/retrieve")
public class RetrieveEmployees extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Retrieve and sort employees
        ArrayList<JSONObject> sortedEmployees = sortEmployees("Employee.json");

        // Write the sorted data to RetrievedEmployees.json
        writeSortedData(sortedEmployees, "RetrievedEmployees.json");

        // Forward to a JSP page or send a response as needed
        // response.getWriter().println("Sorting and writing completed successfully.");
    }

    private ArrayList<JSONObject> sortEmployees(String inputFilename) {
        ArrayList<JSONObject> sortedList = new ArrayList<>();

        try {
            // Read JSON data from the input file
            JSONParser parser = new JSONParser();
            JSONObject jsonData = (JSONObject) parser.parse(new FileReader(inputFilename));
            JSONArray employeeArray = (JSONArray) jsonData.get("results");

            // Filter employees who know Java and have a score greater than 50
            for (Object employeeObj : employeeArray) {
                JSONObject employee = (JSONObject) employeeObj;
                JSONArray knownLanguages = (JSONArray) employee.get("KnownLanguages");

                if (hasJavaAndScoreAbove50(knownLanguages)) {
                    sortedList.add(employee);
                }
            }

            // Sort the list based on the Java language score
            // Collections.sort(sortedList, Comparator.comparingLong(this::getJavaScore));


        } catch (Exception e) {
            e.printStackTrace();
        }

        return sortedList;
    }

    private boolean hasJavaAndScoreAbove50(JSONArray knownLanguages) {
        for (Object langObj : knownLanguages) {
            JSONObject language = (JSONObject) langObj;
            String languageName = (String) language.get("LanguageName");
            long score = (long) language.get("ScoreOutof100");

            if ("Java".equalsIgnoreCase(languageName) && score > 50) {
                return true;
            }
        }
        return false;
    }

    private long getJavaScore(JSONObject employee) {
        JSONArray knownLanguages = (JSONArray) employee.get("KnownLanguages");

        for (Object langObj : knownLanguages) {
            JSONObject language = (JSONObject) langObj;
            String languageName = (String) language.get("LanguageName");
            long score = (long) language.get("ScoreOutof100");

            if ("Java".equalsIgnoreCase(languageName)) {
                return score;
            }
        }
        return 0;
    }

    private void writeSortedData(ArrayList<JSONObject> list, String filename) {
        try (FileWriter fileWriter = new FileWriter(filename)) {
            JSONObject result = new JSONObject();
            result.put("results", list);

            fileWriter.write(result.toJSONString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
// private static class JSONComparator implements Comparator<JSONObject> {
//         @Override
//         public int compare(JSONObject o1, JSONObject o2) {
//             long score1 = getJavaScore(o1);
//             long score2 = getJavaScore(o2);

//             return Long.compare(score1, score2);
//         }

//         private long getJavaScore(JSONObject employee) {
//             JSONArray knownLanguages = (JSONArray) employee.get("KnownLanguages");

//             for (Object langObj : knownLanguages) {
//                 JSONObject language = (JSONObject) langObj;
//                 String languageName = (String) language.get("LanguageName");
//                 long score = (long) language.get("ScoreOutof100");

//                 if ("Java".equalsIgnoreCase(languageName)) {
//                     return score;
//                 }
//             }
//             return 0;
//         }
//     }*/