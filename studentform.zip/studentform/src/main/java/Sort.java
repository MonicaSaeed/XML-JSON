// import java.io.File;
// import java.io.IOException;
// import java.util.ArrayList;
// import java.util.Collections;
// import java.util.Comparator;

// import org.w3c.dom.Document;
// import org.w3c.dom.Element;
// import org.w3c.dom.Node;
// import org.w3c.dom.NodeList;
// import javax.xml.parsers.DocumentBuilder;
// import javax.xml.parsers.DocumentBuilderFactory;
// import javax.xml.parsers.ParserConfigurationException;
// import javax.xml.transform.Transformer;
// import javax.xml.transform.TransformerException;
// import javax.xml.transform.TransformerFactory;
// import javax.xml.transform.dom.DOMSource;
// import javax.xml.transform.stream.StreamResult;

// public class Sort {

//     public static void main(String[] args) {
//         sortXmlFile("Students.xml", "student", "name");
//     }
//     /**
//      * @param filePath
//      * @param elementToSort
//      * @param childElementName
//      */
//         public static void sortXmlFile(String filePath, String elementToSort, String childElementName) {
//         try {
//             // Load XML file
//             DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
//             DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
//             Document doc = docBuilder.parse(filePath);

//             // Get the NodeList of elements to sort
//             ArrayList<Element> elements = getElementsList(doc.getDocumentElement());

//         Collections.sort(elements, new Comparator<Element>() {
//                 @Override
//                 public int compare(Element element1, Element element2) {
//                     String value1 = ((Element) element1).getElementsByTagName(childElementName).item(0).getTextContent();
//                     String value2 = ((Element) element2).getElementsByTagName(childElementName).item(0).getTextContent();
//                     return value1.compareTo(value2);
//                 }
//             });

//             // Save the sorted NodeList back to the XML file
//             saveXmlToFile(doc, filePath);

//         } catch (ParserConfigurationException | IOException | org.xml.sax.SAXException | TransformerException e) {
//             e.printStackTrace();
//         }
//     }

//     private static void saveXmlToFile(Document doc, String filePath) throws TransformerException {
//         // Save the updated document to the file
//         TransformerFactory transformerFactory = TransformerFactory.newInstance();
//         Transformer transformer = transformerFactory.newTransformer();
//         DOMSource source = new DOMSource(doc);
//         StreamResult result = new StreamResult(new File(filePath));
//         transformer.transform(source, result);
//     }

//     private static ArrayList<Element> getElementsList(Element element) {
//         ArrayList<Element> elements = new ArrayList<>();
//         NodeList nodeList = element.getChildNodes();

//         for (int i = 0; i < nodeList.getLength(); i++) {
//             Node node = nodeList.item(i);

//             if (node.getNodeType() == Node.ELEMENT_NODE) {
//                 elements.add((Element) node);
//             }
//         }

//         return elements;
//     }
// }



