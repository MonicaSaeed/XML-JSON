import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XmlSorter {

    // Sort elements of an XML document based on a specified attribute
    public static ArrayList<Element> sortElementsByAttribute(Document doc, final String attributeName,
            final boolean ascending) {

        // Get the NodeList of elements to sort
        ArrayList<Element> elements = getElementsList(doc.getDocumentElement());

        // Perform sorting based on the specified attribute and order
        Collections.sort(elements, new Comparator<Element>() {
            @Override
            public int compare(Element element1, Element element2) {
                String attributeValue1 = element1.getAttribute(attributeName);
                String attributeValue2 = element2.getAttribute(attributeName);

                // Perform comparison based on attribute type (integer or string)
                return compareAttributeValues(attributeValue1, attributeValue2, ascending);
            }
        });

        return elements;
    }

    // Compare two attribute values based on their types (integer or string)
    private static int compareAttributeValues(String value1, String value2, boolean ascending) {
        // Check if attributes are integers
        boolean isIntAttribute = isInteger(value1) && isInteger(value2);

        if (isIntAttribute) {
            int int1 = Integer.parseInt(value1);
            int int2 = Integer.parseInt(value2);

            // Perform integer comparison
            return ascending ? Integer.compare(int1, int2) : Integer.compare(int2, int1);
        } else {
            // Perform string comparison
            return ascending ? value1.compareTo(value2) : value2.compareTo(value1);
        }
    }

    // Get a list of elements from the XML document
    private static ArrayList<Element> getElementsList(Element element) {
        ArrayList<Element> elements = new ArrayList<>();
        NodeList nodeList = element.getChildNodes();

        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);

            if (node.getNodeType() == Node.ELEMENT_NODE) {
                elements.add((Element) node);
            }
        }

        return elements;
    }

    // Helper method to check if a string represents an integer
    private static boolean isInteger(String s) {
        try {
            Integer.parseInt(s);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Save the sorted XML to a file
    public static void saveSortedXml(ArrayList<Element> sortedElements, String filename) {
        try {
            // Create a new Document for the sorted content
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document sortedDoc = dBuilder.newDocument();

            // Create the root element for the sorted content
            Element rootElement = sortedDoc.createElement("University");
            sortedDoc.appendChild(rootElement);

            // Import and append each sorted element to the new Document
            for (Element element : sortedElements) {
                Node importedNode = sortedDoc.importNode(element, true);
                rootElement.appendChild(importedNode);
            }

            // Configure the transformer for pretty-printing
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");

            // Write the sorted content to the specified file
            DOMSource source = new DOMSource(sortedDoc);
            StreamResult result = new StreamResult(new java.io.File(filename));
            transformer.transform(source, result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
